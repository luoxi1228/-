package ChatSystem.Start;

        import ChatSystem.UI.login;

public class ClientStartup {
    public static void main(String[] args) {
        new login();
    }
}


