package ChatSystem.Start;

import ChatSystem.Server.Server;

public class SeverStartup {
    public static void main(String[] args) {
        new Server();
    }
}
